## Redmine Alex skin

#### Skin for Redmine

Skin for Redmine with user-friendly interface and usefull with plugins of our team.

![Interface](https://github.com/tdvsdv/redmine_alex_skin/raw/master/screenshots/interface.png "Interface")

======

[usability]: https://bitbucket.org/dkuk/usability
Redmine Alex skin is recommended to use with plugin [Usability][usability].
It made interface of Redmine user-friendly.

![Interface2](https://github.com/tdvsdv/redmine_alex_skin/raw/master/screenshots/interface2.png "Interface2")

#### Installation
To install skin, go to the folder "../public/themes" in root directory of Redmine.
Clone skin in that folder.

		git clone https://bitbucket.org/dkuk/redmine_alex_skin.git

Restart your web-server.

Go to Redmine settings, tab "Display" and change theme to "Redmine alex skin".

#### Supported Redmine versions.

Skin aims to support and is tested under the following Redmine implementations:
* Redmine 2.4.x
* Redmine 2.5.x
* Redmine 2.6.x
* Redmine 3.0.x

#### Copyright
Copyright (c) 2011-2013 Vladimir Pitin, Danil Kukhlevskiy.

Plugins of our team you can see on site http://rmplus.pro
